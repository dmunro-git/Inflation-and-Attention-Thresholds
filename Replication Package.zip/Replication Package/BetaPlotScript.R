
#Set appropriate file path below
BetaDat<-read.table("/Users/.../BetaPlot.csv",sep=',',header=T)
BetaDatPost2010<-read.table("/Users/.../BetaPlotPost2010.csv",sep=',',header=T)

library(tidyverse)

#Plot for all data
ggplot(BetaDat, aes(x=B1, y=B0, alpha=Fstat))+
  geom_point(size = 2, show.legend=FALSE) +
  geom_hline(aes(yintercept = 0),linetype = "dashed") +
  geom_vline(aes(xintercept = 0),linetype = "dashed")+
  geom_abline(aes(intercept = 0, slope=1),linetype = "dashed",colour="red")+
  theme_bw()+ylab("") + xlab("")+ 
  xlim(-20, 20)+
  ylim(-20, 20)+ 
  geom_text(aes(label="\u03B2 1"), 
            x=-20,
            y=-2,
            color = "black",show.legend=FALSE
  )+
  geom_text(aes(label="\u03B2 0"), 
            x=2,
            y=-20,
            color = "black", show.legend=FALSE
  )

#Plot as robustness check on post-2010 data after Google Trends geographic improvements

ggplot(BetaDatPost2010, aes(x=B1, y=B0, alpha=Fstat))+
  geom_point(size = 2, show.legend=FALSE) +
  geom_hline(aes(yintercept = 0),linetype = "dashed") +
  geom_vline(aes(xintercept = 0),linetype = "dashed")+
  geom_abline(aes(intercept = 0, slope=1),linetype = "dashed",colour="red")+
  theme_bw()+ylab("") + xlab("")+ 
  xlim(-20, 20)+
  ylim(-20, 20)+ 
  geom_text(aes(label="\u03B2 1"), 
            x=-20,
            y=-2,
            color = "black",show.legend=FALSE
  )+
  geom_text(aes(label="\u03B2 0"), 
            x=2,
            y=-20,
            color = "black", show.legend=FALSE
  )
